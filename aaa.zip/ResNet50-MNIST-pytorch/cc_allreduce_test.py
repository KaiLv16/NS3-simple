from collective_communication_lib import * 


if __name__ == '__main__':
    # Example usage
    N = 2
    total_data_size = 60
    flows = ring_all_reduce(N, total_data_size)

    flow_num = 0
    for chunk, flow_list in flows.items():
        print(f"Chunk {chunk}")
        flow_num += len(flow_list)
        for flow in flow_list:
            print(flow)
    print(f"All-Reduce operation with DpGrpNum = {N} has {flow_num} flows. ")
