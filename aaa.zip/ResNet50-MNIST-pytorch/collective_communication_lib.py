from collections import defaultdict
from hardware_model import *


class cc_Flow:
    def __init__(self, flow_id, src, dst, size, opcode, round, data_depend, flow_depend, data_invoke, flow_invoke):
        self.flow_id = flow_id
        self.src = src
        self.dst = dst
        self.size = size
        self.opcode = opcode
        self.round = round
        self.data_depend = data_depend
        self.flow_depend = flow_depend
        self.data_invoke = data_invoke
        self.flow_invoke = flow_invoke

    def __repr__(self):
        return f"cc_Flow(flow_id={self.flow_id}, src={self.src}, dst={self.dst}, size={self.size}, op={self.opcode}, round={self.round}, data_depend={self.data_depend}, flow_depend={self.flow_depend}, data_invoke={self.data_invoke}, flow_invoke={self.flow_invoke})"


def ring_all_reduce(N, total_data_size):
    assert N > 1, f"Exception when generating AllReduce flows: DP grp must bigger than 1!"
    flows = defaultdict(list)
    flow_data_size = total_data_size / N

    data_chunk_start_idx = [i for i in range(N)]
    data_chunk_idx = [i for i in range(N)]
    
    for chunk in range(N):
        chunk_flow_id = 0
        # reduce-scatter
        for round in range(N - 1):
            data_depend = []
            flow_depend = []
            flow_invoke = []
            data_invoke = []
            src = data_chunk_idx[chunk]
            dst = (data_chunk_idx[chunk] + 1) % N
            data_chunk_idx[chunk] = (data_chunk_idx[chunk] + 1) % N
            data_depend.append(f'node{src}_chunk{(src - round + N) % N}.READY')
            if round > 0:
                flow_depend.append(f"chunk{chunk}_flow{chunk_flow_id - 1}")
            flow_invoke.append(f"chunk{chunk}_flow{chunk_flow_id + 1}")
            # if round == N - 2:
            #     data_invoke.append(f"node{(data_chunk_start_idx[chunk] + chunk_flow_id + 1) % N}_chunk{chunk}.DONE")      # should be 'READY' state here.
            flow = cc_Flow(f"chunk{chunk}_flow{chunk_flow_id}", src, dst, flow_data_size, 'reduce-scatter', round, data_depend, flow_depend, data_invoke, flow_invoke)
            flows[chunk].append(flow)
            chunk_flow_id += 1
        # all-gather
        for round in range(N - 1, 2 * N - 2):
            data_depend = []
            flow_depend = []
            flow_invoke = []
            data_invoke = []
            src = data_chunk_idx[chunk]
            dst = (data_chunk_idx[chunk] + 1) % N
            data_chunk_idx[chunk] = (data_chunk_idx[chunk] + 1) % N
            if round == N - 1:
                data_depend.append(f'node{src}_chunk{(src - round + N) % N}.READY')
                data_invoke.append(f"node{(data_chunk_start_idx[chunk] + chunk_flow_id) % N}_chunk{chunk}.DONE")   # TODO: not in time but accurate
            flow_depend.append(f"chunk{chunk}_flow{chunk_flow_id - 1}")
            if round < 2 * N - 2 - 1:
                flow_invoke.append(f"chunk{chunk}_flow{chunk_flow_id + 1}")
            
            data_invoke.append(f"node{(data_chunk_start_idx[chunk] + chunk_flow_id + 1) % N}_chunk{chunk}.DONE")
            flow = cc_Flow(f"chunk{chunk}_flow{chunk_flow_id}", src, dst, flow_data_size, 'all-gather', round, data_depend, flow_depend, data_invoke, flow_invoke)
            flows[chunk].append(flow)
            chunk_flow_id += 1

    return flows


def cc_wrapper(tensor_list, cc_mode='all-reduce'):
    '''
    returns a list of CC flow.
    tensor = layer in this circumistance
    每个流应该有：全局唯一的flowid，由 flowid_assigner() 生成
    每个节点的特性：读数据时间、写数据时间、计算时间
    每个节点应该有：依赖流ID列表flows_depend、触发流ID列表flows_invoke。
    '''
    N = len(tensor_list)

    # legality check
    data_size_list = [tensor.param_num * tensor.dtype_size for tensor in tensor_list]
    for i in range(1, len(data_size_list)):
        if data_size_list[i - 1] != data_size_list[i]:
            raise Exception(f"Data size not equal in DP Grp.")
    
    # main logic. new CC algo can be inserted.
    if cc_mode == 'all-reduce':
        flows = ring_all_reduce(N, data_size_list[0])
    else:
        raise Exception(f"'{cc_mode}' not implemented yet.")
    
    for chunk, flow_list in flows:      # chunk is useless here, we just want to see the flows.
        for flow in flow_list:
            src_layer_index = tensor_list[flow.src].layer_index              # flow.src & flow.src are actually DP index. We use them to recover layer_id or name.
            dst_layer_index = tensor_list[flow.dst].layer_index
            Flow(flowid_assigner(), srchost, srcgpu, srcnic, dsthost, dstgpu, dstnic, flow.size, lat=-1)




    def tree_all_reduce(self, tensor_list):

        pass

    def hierarchical_all_reduce(self, tensor_list):

        pass




