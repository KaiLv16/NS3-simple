import torch
import math
from nets.resnet50 import Bottleneck, ResNet
import torch.fx as fx
import pandas as pd
from functools import reduce
from operator import mul

from utils_get_fx_graph import *
from hardware_model import *
from collective_communication_lib import *



# 提取GraphModule信息并转换为DataFrame
def graph_module_to_dataframe(graph_module, input_size, batch_size=1):
    # # 前向传播过程中记录每个节点的输出形状
    input_shapes = {}
    output_shapes = {}
    param_shapes = {}
    param_num = {}
    dtype_size = {}
    layer_types = {}
    input_output_shapes = {}

    count_dict = {}
    def update_count(key):
        if key in count_dict:
            count_dict[key] += 1
        else:
            count_dict[key] = 0
        return count_dict[key]

    def record_input_output_shapes(module, input, output):
        module_name = ''
        # print("--------------------------------------------------")
        for name, mod in model.named_modules():
            # print(name, mod)
            
            if mod is module:
                module_name = name
                index = update_count(module_name)
                if index > 0:
                    module_name = name.replace('.', '_') + '_' + str(index)
                else:
                    module_name = name.replace('.', '_')
                # print(module_name)
                break
        
        input_shapes[module_name] = input[0].shape if isinstance(input, tuple) else input.shape
        output_shapes[module_name] = output.shape
        # 记录参数形状
        param_shapes[module_name] = {name: p.shape for name, p in module.named_parameters()}
        param_size = 0
        for _, p in module.named_parameters():
            param_size += torch.prod(torch.tensor(p.shape)).item()
        param_num[module_name] = int(param_size)
        dtype_size[module_name] = [output.element_size()]
        layer_types[module_name] = type(module).__name__

        input_output_shapes[module_name] = {
            'input_shape': input_shapes[module_name],
            'output_shape': output_shapes[module_name],
            'Param #': param_num[module_name],
            'param_shape': param_shapes[module_name],
            'dtype_size': dtype_size[module_name],
            'layer_type': layer_types[module_name]
        }

    # 注册钩子
    hooks = []
    for name, module in model.named_modules():
        if not isinstance(module, torch.nn.Sequential):
            hooks.append(module.register_forward_hook(record_input_output_shapes))

    # 前向传播,  创建一个dummy输入
    x = torch.rand(batch_size, *input_size)
    with torch.no_grad():
        model(x)

    # 移除钩子
    for hook in hooks:
        hook.remove()


    node_info = {
        "name": [],
        "args": [],
        "input_#": [],
        "output_#": [],
        "Param_#": [],
        "dp_index": 0,
        "pp_index": 0,
        "tp_index": 0,  # currently not used

        "opcode": [],
        "target": [],
        "layer_type": [],
        "input_shape": [],
        "output_shape": [],
        "param_shape": [],
        "kwargs": [],
        "dtype_size": []
    }

    for node in graph_module.graph.nodes:
        node_info["name"].append(node.name)
        node_info["opcode"].append(node.op)
        node_info["target"].append(node.target)
        node_info["args"].append(node.args)
        node_info["kwargs"].append(node.kwargs)

        # 获取输入和输出形状以及参数形状
        # print(node.name)
        if node.op == 'call_module' or node.name in input_output_shapes:
            node_info["input_shape"].append(list(input_output_shapes[node.name]['input_shape']))
            node_info["output_shape"].append(list(input_output_shapes[node.name]['output_shape']))
            node_info["param_shape"].append(input_output_shapes[node.name]['param_shape'])
            node_info["dtype_size"].append(input_output_shapes[node.name]['dtype_size'])
            node_info["input_#"].append(reduce(mul, list(input_output_shapes[node.name]['input_shape'])))
            node_info["output_#"].append(reduce(mul, list(input_output_shapes[node.name]['output_shape'])))
            node_info["Param_#"].append(input_output_shapes[node.name]['Param #'])
            node_info["layer_type"].append(input_output_shapes[node.name]['layer_type'])
        else:
            if len(node_info["output_shape"]) > 0:     # 用于处理原本为None的情况：给前后层连起来
                node_info["input_shape"].append(node_info["output_shape"][-1])
                node_info["output_shape"].append(node_info["output_shape"][-1])
                node_info["param_shape"].append(0)
                node_info["dtype_size"].append(node_info["dtype_size"][-1])
                node_info["input_#"].append(reduce(mul, node_info["output_shape"][-1]))
                node_info["output_#"].append(reduce(mul, node_info["output_shape"][-1]))
                node_info["Param_#"].append(0)
                node_info["layer_type"].append(None)    # dont care
            else:
                node_info["input_shape"].append(None)
                node_info["output_shape"].append(None)
                node_info["param_shape"].append(None)
                node_info["dtype_size"].append(None)
                node_info["input_#"].append(0)
                node_info["output_#"].append(0)
                node_info["Param_#"].append(0)
                node_info["layer_type"].append(None)

    df = pd.DataFrame(node_info)
    return df


# 支持的模式： 'avg_mem' 和 'min_comm'
def model_pp_cut(df, stages=8, cut_mode='avg_mem'):
    print("cut_mode =", cut_mode)
    if stages < 1:
        stages = 1
    if 'avg_mem' in cut_mode:
        print("avg_mem!")
        update_dataframe(df, 'Param_#', stages)
        
    elif 'min_comm' in cut_mode:
        print("min_comm!")
        avg_param_per_host = df['Param_#'].sum() / stages
        # 单核版本有点bug（边界条件）
        # find_feasible_partition_min_comm_single_core(df, stages, avg_param_per_host * 2)
        find_feasible_partition_min_comm_multi_core(df, stages, avg_param_per_host * 2)
    else:
        print("Error: In function 'model_pp_cut()': cut_mode unrecognized! ")


# currently support 'avg_mem'.
def get_compute_density_ops_and_time(df, fwd_df=None, pass_type='FWD'):
    assert pass_type in ['FWD', 'BKWD'], f"Unrecognized pass_type {pass_type}!"
    df['compute_density_ops'] = 0
    for i in range(len(df)):
        if df['layer_type'][i] == None:
            df.at[i, 'compute_density_ops'] = df['input_#'][i]

        else:
            if df['layer_type'][i].lower() == 'conv2d'.lower():
                kernel_shape = list(df['param_shape'][i]['weight'])[-3:]
                df.at[i, 'compute_density_ops'] = reduce(mul, kernel_shape) * df['output_#'][i]

            elif df['layer_type'][i].lower() == 'BatchNorm2d'.lower():
                a = df['input_#'][i]
                b = list(df['param_shape'][i]['weight'])[0]
                c = list(df['param_shape'][i]['bias'])[0]
                calc_avg = a + 4 * b     # a次加法 b次除法。认为除法是加法的4倍
                calc_square_err = a * (1 + 2 + 1) + 4 * b  # a次减法 a次平方 a次加法 b次除法
                calc_norm = a * (1 + 4 + 4 + 1)  # 对每个输入进行归一化需要a次减法、平方根、除法和加法
                calc_result = a * (1 + 2)   # 对每个输入应用缩放和平移需要a次乘法和加法
                df.at[i, 'compute_density_ops'] = calc_avg + calc_square_err + calc_norm + calc_result

            elif df['layer_type'][i].lower() == 'ReLU'.lower():
                df.at[i, 'compute_density_ops'] = df['input_#'][i] * 4

            elif df['layer_type'][i].lower() == 'MaxPool2d'.lower():
                pool_num = df['output_#'][i]
                compare_per_pool = df['input_#'][i] / df['output_#'][i]
                df.at[i, 'compute_density_ops'] = pool_num * compare_per_pool

            elif df['layer_type'][i].lower() == 'AvgPool2d'.lower():
                pool_num = df['output_#'][i]
                compare_per_pool = df['input_#'][i] / df['output_#'][i] + 4
                df.at[i, 'compute_density_ops'] = pool_num * compare_per_pool

            elif df['layer_type'][i].lower() == 'Linear'.lower():
                batch_size = math.sqrt(df['input_#'][i] * df['output_#'][i])
                calc_mul = df['Param_#'][i] * batch_size * (1 + 2)   # 乘加
                calc_offset = df['output_#'][i]
                df.at[i, 'compute_density_ops'] = calc_mul + calc_offset

            else:
                raise Exception("Unrecognized layer type!")
        
            # Conv2D: 约 2 倍
            # BatchNorm2D: 约 2 倍
            # ReLU: 1 倍
            # MaxPool2D: 约 2 倍
            # AvgPool2D: 1 倍
            # Linear: 约 2 倍
            
            if pass_type == 'BKWD':
                fwd_cpt = -1
                for j in range(len(fwd_df)):
                    if fwd_df['name'][j] == df['name'][i]:
                        fwd_cpt = fwd_df['compute_density_ops'][j]
                        break
                if fwd_cpt == -1:
                    raise Exception(f"layer {df['name'][i]} not found in fwd_df!")
                if df['layer_type'][i].lower() in ['conv2d', 'batchnorm2d', 'maxpool2d', 'linear']:
                    df.at[i, 'compute_density_ops'] = fwd_cpt * 2
                else:
                    df.at[i, 'compute_density_ops'] = fwd_cpt


def bkwd_df_gen(df):
    # 反转DataFrame的行顺序
    def generate_bkwd_df(fwd_df):
        # 初始化输出节点的依赖字典
        output_dependencies = defaultdict(list)
        # 填充输出节点的依赖字典
        for idx, row in fwd_df.iterrows():
            for arg in row['args']:
                output_dependencies[str(arg)].append(row['name'])
        # 逆序 fwd_df，并保持其他列不变
        print(output_dependencies)

        reversed_df = fwd_df.iloc[::-1].reset_index(drop=True)
        # 更新 reversed_df 中的依赖关系
        for i in range(len(reversed_df)):
            reversed_df.at[i, 'args'] = tuple(output_dependencies[reversed_df['name'][i]])
                
        # print(fwd_df)
        # print(reversed_df)
        return reversed_df
    
    bkwd_df = generate_bkwd_df(df)
    
    # 修改其他性质
    for i in range(len(bkwd_df)):
        bkwd_df.at[i, 'direction'] = 'BKWD'
        bkwd_df.at[i, 'input_#'] = bkwd_df['output_#'][i]
        bkwd_df.at[i, 'output_#'] = bkwd_df['input_#'][i]
        bkwd_df.at[i, 'input_shape'] = bkwd_df['output_shape'][i]
        bkwd_df.at[i, 'output_shape'] = bkwd_df['input_shape'][i]
    return bkwd_df

# currently support 'avg_mem'.
def sim_node_gen(fwd_df, bkwd_df, total_iter=1, bypass_first_fwd=False, bypass_last_bkwd = False):

    assert total_iter > 0, 'You specified a total_iter that <= 0!'
    assert len(fwd_df) == len(bkwd_df), f"Error: len(fwd_df) ({len(fwd_df)}) != len(bkwd_df) ({len(bkwd_df)})"
    assert ~(total_iter == 1 and bypass_first_fwd == True and bypass_last_bkwd == True), \
            f"you've set total_iter = 1, bypass_first_fwd = True and bypass_last_bkwd = True, which cannot form a single pass. "
    
    for i in range(len(fwd_df)):
        fwd_df.at[i, 'name'] = fwd_df['name'][i] + '_fwd'

    for i in range(len(bkwd_df)):
        bkwd_df.at[i, 'name'] = bkwd_df['name'][i] + '_bkwd'

    pass_template = {}
    
    # since we have fwd_df and bkwd_df, start generating sim_nodes...
    iters = [i//2 for i in range(total_iter * 2)]  # [0, 1]一组，[2, 3]一组，...
    if bypass_first_fwd == True:
        iters[0] = -1
    if bypass_last_bkwd == True:
        iters[total_iter * 2 - 1] = -1
    
    sim_df = None
    for i in range(total_iter * 2):
        pass_template['FWD'] = fwd_df.copy(deep=True)
        pass_template['BKWD'] = bkwd_df.copy(deep=True)
        has_pass = (iters[i] != -1)
        pass_type = 'FWD' if (i % 2) == 0 else 'BKWD'
        if has_pass:
            layers_tmp = pass_template[pass_type]
            for j in range(len(layers_tmp)):
                my_args = []
                for s in layers_tmp['args'][j]:
                    if isinstance(s, torch.fx.node.Node):
                        my_args.append(s.name + '_' + str(pass_type.lower()) + '_' + str(i // 2))
                    elif isinstance(s, int):
                        print(f"{i // 2}: Layer {layers_tmp['name'][j]} has args {s} that is not of type 'torch.fx.node.Node', but {type(s)}")
                        my_args.append(s)
                    elif isinstance(s, str):
                        my_args.append(s + '_' + str(pass_type.lower()) + '_' + str(i // 2))
                    else:
                        raise Exception(f"{i // 2}: Layer {layers_tmp['name'][j]} has args {s} that is not of type 'torch.fx.node.Node', but {type(s)}")

                        
                # layers_tmp.at[j, 'args'] = tuple(s.name + '_' + str(pass_type.lower()) + '_' + str(i // 2) for s in layers_tmp['args'][j])
                layers_tmp.at[j, 'args'] = tuple(my_args)
                layers_tmp.at[j, 'name'] = layers_tmp['name'][j] + '_' + str(i // 2)

            if not isinstance(sim_df, pd.DataFrame):
                sim_df = layers_tmp
            else:
                layers_tmp.at[0, 'args'] = tuple([sim_df.iloc[-1]['name']])
                sim_df = pd.concat([sim_df, layers_tmp], axis=0).reset_index(drop=True)
    
    return sim_df


if __name__ == '__main__':
    # 设置 Pandas 显示选项，不折叠输出
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', None)
    pd.set_option('display.max_colwidth', None)


    model = ResNet(Bottleneck, [3, 4, 6, 3], num_classes=10)
    # 使用FX跟踪模型
    tracer = fx.Tracer()
    graph = tracer.trace(model)                 # 创建计算图
    print("print(graph)")
    print(graph)

    graph_module = fx.GraphModule(model, graph) # 创建GraphModule
    traced = fx.symbolic_trace(model)           # 创建symbolic的计算图
    print(traced)
    fwd_df = graph_module_to_dataframe(traced, input_size=(1, 28, 28), batch_size=10)
    print(print(fwd_df))
    print(fwd_df)
    
    fwd_df['layer_index'] = fwd_df.index

    fwd_df['direction'] = 'FWD'
    # 将 'layer_index' 列移动到第一列
    fwd_df = fwd_df[['layer_index'] + [col for col in fwd_df.columns if col != 'layer_index']]
    # 模型使用pp切分
    model_pp_cut(fwd_df, stages=8, cut_mode='avg_mem')
    # print(traced_df)
    model_pp_cut(fwd_df, stages=8, cut_mode='min_comm')
    print("print(df_after_cut)")
    print(fwd_df)

    # print(traced_df['args'][15])
    # print(type(traced_df['args'][15]))
    # traced_df = sim_node_gen(traced_df, bypass_first_fwd=True, bypass_last_bkwd = True)
    bkwd_df = bkwd_df_gen(fwd_df)

    get_compute_density_ops_and_time(fwd_df, 'FWD')
    get_compute_density_ops_and_time(bkwd_df, fwd_df, 'BKWD')

    # print(type(fwd_df['args'][2][0]))

    print(f"\nforward layers:\n")
    print(fwd_df)
    print(f"\nbackward layers:\n")
    print(bkwd_df)

    sim_df = sim_node_gen(fwd_df, bkwd_df, total_iter=2, bypass_first_fwd=True, bypass_last_bkwd = True)
    sim_df['global_index'] = sim_df.index
    sim_df = sim_df[['global_index'] + [col for col in sim_df.columns if col != 'global_index']]
    print(f"\nsim layers:\n")
    print(sim_df)
    if sim_df is not None:
        sim_df.to_csv('sim_df.csv', index=False)

    # 将单个模型的流复制到多个DP
    DP_Grp_Size = 2
    DP_sim_grp = []
    for i in range(DP_Grp_Size):
        DP_sim_grp.append(sim_df.copy(deep=True))


    
    



    