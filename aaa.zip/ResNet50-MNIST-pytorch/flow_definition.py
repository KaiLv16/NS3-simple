# 全局 flow ID 分发器
global_flowid_register = -1

def flowid_assigner():
    global_flowid_register += 1
    return global_flowid_register

class FlowEndpointInfo:
    def __init__(self, host, gpu, nic):
        self.host = host
        self.gpu = gpu
        self.nic = nic

class Flow:
    def __init__(self, id, size, srcEp, dstEp, opcode='pp', round=-1, lat=-1):
        self.id = id        # 全局唯一的flowid
        self.size = size
        assert isinstance(srcEp, FlowEndpointInfo)
        assert isinstance(dstEp, FlowEndpointInfo)
        self.srcEp = srcEp
        self.dstEp = dstEp
        self.opcode = opcode
        self.round = round
        self.lat = lat
        self.flow_depend = []   # TODO: 想想怎么定义？需要包含哪些要素？需要包含PP和DP，后期需要扩展TP
        self.data_depend = []
        self.flow_invoke = []
        self.data_invoke = []

    def flow_depend_update():

        pass

    def flow_depend_append():

        pass

    def data_depend_update():

        pass

    def data_depend_append():

        pass

    def flow_invoke_update():

        pass

    def flow_invoke_append():

        pass

    def data_invoke_update():

        pass

    def data_invoke_append():

        pass